package structeg;

import com.opensymphony.xwork2.ActionSupport;

public class hello extends ActionSupport {
	private String name;
	private String sname;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String execute() {
		if(name.equals("Imman")&&sname.equals("Esther")) {
			System.out.println("suc");
		return "success";}
		else {
			System.out.println("fail");
			return "failure";}
		
			
		
		
	}

}
