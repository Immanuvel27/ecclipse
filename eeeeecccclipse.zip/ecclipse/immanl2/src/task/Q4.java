package task;

import java.util.Scanner;

public class Q4 {
	public static int findIndex(int[] arr,int n,int target) {
		int index=0;
		for(int i=0;i<n;i++) {
			if(arr[i]==target) {
				index=i;
				break;
			}else if(arr[i]<target) {
				index=i;
				if(i!=n-1) {
					if(arr[i+1]>target) {
						index=i+1;
					}
				}			
			}
		}
		return index;
	}
	public static void main(String[] args) {
		Scanner cin=new Scanner(System.in);
		int n,target;
		System.out.println("Enter the size of the array:");
		n=cin.nextInt();
		int[] arr=new int[n];
		System.out.println("Enter the array:");		
		for(int i=0;i<n;i++) {
			arr[i]=cin.nextInt();
		}
		System.out.println("Enter the target:");
		target=cin.nextInt();
		
		int index=findIndex(arr, n, target);
		System.out.println("The index:"+index);
	}

}
