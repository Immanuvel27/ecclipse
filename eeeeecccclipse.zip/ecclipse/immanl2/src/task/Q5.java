package task;

import java.util.Scanner;

public class Q5 {
	public static String convert(String str) {
		char[] ch=str.toCharArray();
		int n=str.length();
		int count=0,num=0;
		String str1="";
		
		for(int i=0;i<n;i++) {
			count=0;
			for(int j=i;j<n;j++) {
				if(ch[i]==ch[j]) {
					count+=1;
					i=j;
				}else {
					break;
				}
			}
			str1=str1+count+ch[i];
		}
		
		return str1;
	}
	
	public static void main(String[] args) {
		Scanner cin=new Scanner(System.in);
		String str;
		System.out.println("Enter the integer:");
		str=cin.next();
		String strocc=convert(str);
		
		System.out.println("The occurence string:"+strocc);
		
	}

}
