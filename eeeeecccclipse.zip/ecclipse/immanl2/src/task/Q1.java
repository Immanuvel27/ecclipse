package task;

import java.util.Scanner;

public class Q1 {
	
	public static void convert(String str,int len,int n) {
		char[] ch=str.toCharArray();
		
		
	}
	
	
	public static void main(String[] args) {
		Scanner cin=new Scanner(System.in);
		String str;
		int n;
		System.out.println("Enter the string:");
		str=cin.next();
		System.out.println("Enter the number of rows:");
		n=cin.nextInt();
		int len=str.length();		
		
	}
}
