package eval;

import java.util.Scanner;



public class Q1 {
	public static void main(String[] args) {
		Scanner cin=new Scanner(System.in);
		String str,str1;
		System.out.println("Enter the string:");
		str=cin.next();
		System.out.println("Enter the second string:");
		str1=cin.next();
		boolean check=check(str, str1);
		System.out.println("the result:"+check);
	}
	
	public static boolean check(String str,String str1) {
		int count=0;
		if(str.length()==str1.length()) {
			char[] ch=str.toCharArray();
			char[] ch1=str1.toCharArray();
			for(int i=0,j=0;i<str.length()||j<str.length();i++,j++) {
				if(ch[i]!=ch1[j]) {
					count++;
				}
			}
			
		}else if (str1.length()==str.length()-1) {
			char[] ch=str.toCharArray();
			char[] ch1=str1.toCharArray();
			for(int i=0,j=0;i<str1.length()||j<str1.length();i++,j++) {
				if(ch[i]!=ch1[j]) {
					count++;
					j--;
				}
			}
			if(ch[str.length()-1]!=ch1[str1.length()-1]) {
				count++;
			}
		}else if(str1.length()==str.length()+1) {
			char[] ch=str.toCharArray();
			char[] ch1=str1.toCharArray();
			
			for(int i=0,j=0;i<str.length()||j<str.length();i++,j++) {
				if(ch[i]!=ch1[j]) {
					count++;
					i-=1;
				}
			}
			if(ch[str.length()-1]!=ch1[str1.length()-1]) {
				count++;
			}
			
		}else {
			count+=2;
		}
		
		if(count==0||count==1) {
			return true;
		}
		else {
			return false;
		}
		
		
	}
}
