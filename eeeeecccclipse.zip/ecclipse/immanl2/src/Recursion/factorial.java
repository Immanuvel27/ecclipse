package Recursion;

import java.util.Scanner;

public class factorial {
	
	public static long fact(int n) {
		long factorial=1;
		if(n<=1) {
			return 1;
		}else{
		factorial=n*fact(n-1);
		}
		
		return factorial;
		
	}
	
	public static void main(String[] args) {
		Scanner cin=new Scanner(System.in);
		int n;
		System.out.println("Enter the number to find factorial:");
		n=cin.nextInt();
		long fact=fact(n);
		System.out.println("the factorial is:");
		System.out.println(fact);
	}
}
