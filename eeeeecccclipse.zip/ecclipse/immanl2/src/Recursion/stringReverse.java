package Recursion;

import java.util.Scanner;

public class stringReverse {
	public static void reverse(String str) {
		if(str.isEmpty()) {
			System.out.println("empty");
			
		}
		
	}
	public static void main(String[] args) {
		Scanner cin=new Scanner(System.in);
		String str;
		System.out.println("Enter the string:");
		str=cin.next();
		int n=str.length();
		reverse(str);
		
		
	}
}
