package Recursion;

import java.util.Scanner;

public class SumNto0 {
	
	//method to add 0 to n
	public static int sum(int n) {
		
		if(n<=0) {
			return 0;
		}else {
			return n+sum(n-1);
		}
	}
	
	
	public static void main(String[] args) {
		Scanner cin=new Scanner(System.in);
		System.out.println("Enter the number:");
		int n=cin.nextInt();
		int sum=sum(n);
		System.out.println("The sum of the numbers is:"+sum);
	}
}
