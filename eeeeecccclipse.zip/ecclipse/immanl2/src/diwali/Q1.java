package diwali;

import java.util.Scanner;

public class Q1 {
	public static int findTrap(int[] arr,int n) {
		int n1=0;int min;
		int left = 0,right = 0;
		for(int i=0;i<n;i++) {
			if(arr[i]>0) {
				left=i;
				break;
			}
		}
		
		for(int i=n-1;i>=0;i--) {
			if(arr[i]>0) {
				right=i;
				break;
			}
		}
		System.out.println("left:"+left+"  Right:"+right);
		if(arr[left]>arr[right]) {
			min=arr[right];
		}else {
			min=arr[left];
		}
		
		if(left==right) {
			return 0;
		}else {
			for(int i=left+1;i<right;i++) {
				if(arr[i]<min) {
				n1=n1+(min-arr[i]);
				}
				
			}
		}
		
		
		return n1;
	}
	public static void main(String[] args) {
		Scanner cin=new Scanner(System.in); 
		int n;
		System.out.println("Enter the size of array:");
		n=cin.nextInt();
		int [] arr=new int[n];
		System.out.println("Enter the array:");
		for(int i=0;i<n;i++) {
			arr[i]=cin.nextInt();
		}
		
		
		
		int S=findTrap(arr,n);
		System.out.println("Water trapped is:");
		System.out.println(S);
		
	}

}
