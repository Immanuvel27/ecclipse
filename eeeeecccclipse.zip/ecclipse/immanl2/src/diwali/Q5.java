package diwali;

import java.util.Scanner;

public class Q5 {
	public static void main(String[] args) {
		Scanner cin=new Scanner(System.in);
		int n,target;
		System.out.println("Enter the Size of the array:");
		n=cin.nextInt();
		int[] arr=new int[n];
		for(int i=0;i<n;i++) {
			arr[i]=cin.nextInt();
		}
		System.out.println("Enter the target:");
		target=cin.nextInt();
		
		int sum=0;
		int maxlength=Integer.MIN_VALUE;
		for(int i=0;i<n;i++) {
			sum=0;
			for(int j=i;j<n;j++) {
				sum+=arr[j];
				if(sum==target) {
					if((j-i)>maxlength) {
					maxlength=(j-i)+1;
				}
			}
		}		
		
	}
		boolean f=maxlength==Integer.MIN_VALUE;
		
		if(f) {
			maxlength=0;
		}
		System.out.println("the maxmimum no of elements in subarray:"+maxlength);
		
		

}
}
