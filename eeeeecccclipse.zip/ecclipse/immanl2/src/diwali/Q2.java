package diwali;

import java.util.Scanner;

public class Q2 {
	public static void sort(int[] arr,int n) {
		int temp;
		for(int i=0;i<n;i++) {
			for(int j=i+1;j<n;j++) {
				if(arr[i]>arr[j]) {
					temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
		}
	}
	
	public static void wave(int[] arr,int n) {
		int temp;
		for (int i = 0; i < n-1; i+=2) {
			temp=arr[i];
			arr[i]=arr[i+1];
			arr[i+1]=temp;
		}
	}
	public static void main(String[] args) {
		Scanner cin=new Scanner(System.in);
		int n;
		
		System.out.println("Enter the size of the array:");
		n=cin.nextInt();
		int[] arr=new int[n];
		System.out.println("Enter the array:");
		for(int i=0;i<n;i++) {
			arr[i]=cin.nextInt();
		}
		
		sort(arr, n);
		wave(arr, n);
		System.out.println();
		for(int i=0;i<n;i++) {
			System.out.print(arr[i]+" ");
		}
		
		
	}

}
