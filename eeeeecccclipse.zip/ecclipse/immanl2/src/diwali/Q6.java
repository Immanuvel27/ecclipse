package diwali;

import java.util.Scanner;

public class Q6 {
	public static int findIndex(int[] arr,int[] arr1,int n) {
		int index=0;
		for(int i=0;i<n;i++) {
			if(arr[i]!=arr1[i]) {
				index=i;
				 break;
			}
		}
		return index;
	}
	
	public static void main(String[] args) {
		Scanner cin=new Scanner(System.in);
		int n;
		System.out.println("Enter the size of the array:");
		n=cin.nextInt();
		int[] arr=new int[n];
		int[] arr1=new int[n-1];
		System.out.println("Enter the frist array:");
		for(int i=0;i<n;i++) {
			arr[i]=cin.nextInt();
		}
		System.out.println("Enter the second array:");
		for(int i=0;i<n-1;i++) {
			arr1[i]=cin.nextInt();
		}
		
	
	}
}
