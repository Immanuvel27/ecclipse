package diwali;

import java.util.Scanner;

public class Q4 {
	public static int[] Merge(int[] arr,int[] arr1,int m,int n) {
		int [] arrNew=new int[m+n];
		int k=0;
		for (int i = 0; i < m; i++) {
			arrNew[k++]=arr[i];
		}

		for(int i=0;i<n;i++) {
			arrNew[k++]=arr1[i];
		}

		return(arrNew);
	}

	public static void removeDuplicate(int[] arr,int n) {
		int k=0;
		int [] arr1=new int[n];
		for(int i=0;i<n;i++) {
			for(int j=i+1;j<n;j++) {
				if(arr[i]==arr[j]) {
					arr[j]=-1;
				}
			}
		}

		for(int i=0;i<n;i++) {
			if(arr[i]!=-1) {
				arr1[k++]=arr[i];
			}
		}
		System.out.println("The union array:\n");
		
		for(int i=0;i<k;i++) {
			System.out.print(arr1[i]+" ");
		}
	}


	public static void main(String[] args) {
		Scanner cin=new Scanner(System.in);
		int n,m;

		System.out.println("Enter the size of first array:");
		m=cin.nextInt();
		System.out.println("ENter the size of the second array:");
		n=cin.nextInt();
		int[] arr=new int[m];
		int[] arr1=new int[n];
		System.out.println("Enter the first array");
		for(int i=0;i<m;i++) {
			arr[i]=cin.nextInt();
		}
		System.out.println("Enter the second array");
		for(int i=0;i<n;i++) {
			arr1[i]=cin.nextInt();
		}

		int[] arr2=Merge(arr, arr1, m, n);

		removeDuplicate(arr2, m+n);
		
		
		}

	}


