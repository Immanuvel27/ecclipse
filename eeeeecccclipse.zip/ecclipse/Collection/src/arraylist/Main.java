package arraylist;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner cin=new Scanner(System.in);
		ArrayList<user> users=new ArrayList<user>();
		int choice;

		do {
			System.out.println("\n1:insert\n2:display\n3:Delete\n0:Exit");
			System.out.println("Enter the choice");
			choice=cin.nextInt();

			switch(choice) {
			case 1:{
				int n;
				System.out.println("enter the number of user to be registered");
				n=cin.nextInt();
				
				for (int i = 0;i < n; i++) {
					
					String rno;
					String name;
					String age;
					System.out.println("Enter the rollno");
					rno=cin.next();
					System.out.println("Enter the name:");
					name=cin.next();
					System.out.println("Enter the age:");
					age=cin.next();		
					user u=new user(rno,name,age);
					users.add(u);
				}
			}
			break;
			case 2:{
				for(user user:users) {
					System.out.println();
					System.out.println("the roll no:"+user.getRno());
					System.out.println("the name:"+user.getName());
					System.out.println("the name:"+user.getAge());
				}
				
			}
			break;
			case 3:{int pos;
				System.out.println(users);
				String rno;
				System.out.println("Enter the rollno to be delete:");
				rno=cin.next();
				for(user u:users) {
					if(u.getRno().equals(rno)) {
						System.out.println(u.getName());
					}
				}
				
				
				
			}
			break;
			}


		}while(choice!=0);

	}

}
