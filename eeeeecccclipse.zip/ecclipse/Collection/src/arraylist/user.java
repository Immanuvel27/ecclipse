package arraylist;

import java.util.Scanner;

public class user {
	Scanner cin=new Scanner(System.in);
	private String rno;
	private String name;
	private String age;
	
	public String getRno() {
		return rno;
	}

	public void setRno(String rno) {
		this.rno = rno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	user(String rno,String name,String age){
		this.rno=rno;
		this.name=name;
		this.age=age;
	}
	
	
	
}
