public class AddedObject {

	String Content = "";
	int value;

	public String getCon() {
		return Content;
	}

	public void setCon(String con) {
		this.Content = con;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

}