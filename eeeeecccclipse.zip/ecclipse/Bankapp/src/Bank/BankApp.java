package Bank;

import java.sql.*;
//import java.util.ArrayList;
import java.util.Scanner;

public class BankApp {
	static customer d=new customer();

	public static void main(String[] args) throws SQLException {

		Scanner cin=new Scanner(System.in);
		//		ArrayList<customer> users=new ArrayList<customer>();
		int cc ,no1 ,  choice;
		String pwd;

		do {
			System.out.println("Bank applcation\n");
			System.out.println("1:Register\n2:Login\n0:Exit");
			System.out.println("Enter the choice:");
			cc=cin.nextInt();
			switch(cc) {
			case 1:	
				d.Register();
				break;
			case 2:  {

				System.out.println("Enter the ac no:");
				no1=cin.nextInt();
				System.out.println("Enter the password");
				pwd=cin.next();
				boolean flag=d.Login(no1,pwd);
				if(flag) {
					do {
						customer c=new customer();
						System.out.println("1:Display\n2.Transaction\n3:Transaction history0:exit");
						System.out.println("Enter your choice:");
						choice=cin.nextInt();
						switch(choice) {
						case 1:{
							c.display();
						}
						break;
						case 2:{
							int ch;
							System.out.println("1:Deposit\n2:Withdraw\n3:Account transfer");
							System.out.println("Enter the which transaction to do:");
							ch=cin.nextInt();
							switch (ch) {
							case 1:{
								int no;


								c.deposit();
							}

							break;
							case 2:{
								int no;

							c.withdraw();

							}
							break;
							case 3:{					

								c.Acctransfer();
							}
							break;
							default:
								System.out.println("Enter the correct option....");
								break;
							}

						}
						break;
						case 3:{
							c.transHistory();
						}
						break;

						}
					} while (choice!=0);
				}else {
					System.out.println("User not found");
				}

			}

			}

		} while (cc!=0);


	}

}
