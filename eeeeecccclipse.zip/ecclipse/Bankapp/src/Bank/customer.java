package Bank;
import java.sql.*;
import java.util.*;

public class customer {
	static int account;
	static String pp;
	Scanner cin=new Scanner(System.in);
	private int custid;
	private int acno;
	private String name;
	private int balance;
	private String pwd;


	//constructor
	public customer() {

		// TODO Auto-generated constructor stub
		custid=0;
		acno=0;
		name=null;
		balance=1000;
		pwd=null;
	}

	//getters and setters 
	public int getCustid() {
		return custid;
	}
	public void setCustid(int custid) {
		this.custid = custid;
	}
	public int getAcno() {
		return acno;
	}
	public void setAcno(int acno) {
		this.acno = acno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}


	//register the customer
	public void Register() throws SQLException {
		Random randomGenerator = new Random();
		String re,p,s="";
		//	 System.out.println("Enter the customer id:");
		this.custid=randomGenerator.nextInt(100);
		//	 System.out.println("Enter the account number:");

		this.acno=randomGenerator.nextInt(1000);
		System.out.println("Enter the customer name:");
		this.name=cin.next();
		do {
			System.out.println("Enter the password:");
			p=cin.next();
			System.out.println("RE-Enter the password:");
			re=cin.next();

			if(!p.equals(re)) {
				System.out.println("the password and re-Enter password doesnot match");
			}
		}while(!p.equals(re));

		if(p.equals(re)) {
			s=encrypt(p); 
		}
		this.pwd=s;
		try {
			Dbcon db=new Dbcon();
			Connection con=db.dbco();
			Statement st=con.createStatement();
			st.executeUpdate("insert ignore into customer values ('"+this.custid+"','"+this.acno+"','"+this.name+"','"+this.balance+"','"+this.pwd+"')");

		} catch (Exception e) {
			e.printStackTrace();
		}


		System.out.println("your cust id:\t"+this.custid+"\nAccount number:\t"+this.acno);
	}


	//displaying the bank details
	public void display() {
		int id;
		String p;
//		System.out.println("Enter the Account no");
//		id=cin.nextInt();
		System.out.println("enter the password");
		p=cin.next();
		p=encrypt(p);
		try {
			Dbcon db=new Dbcon();
			Connection con=db.dbco();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from customer where acno='"+account+"'and pwd='"+p+"'");
			if(rs.next()) {
				System.out.println("The customer id:"+rs.getInt("custid"));

				System.out.println("The account number:"+rs.getInt("acno"));

				System.out.println("The customer name:"+rs.getString("name"));

				System.out.println("The balance:"+rs.getDouble("balance"));

				System.out.println("The password:"+rs.getString("pwd"));
				System.out.println();

			}else {
				System.out.println("Given details are wrong");
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}
	
	
	
	public boolean search(int id) {

		try {
			Dbcon db=new Dbcon();
			Connection con=db.dbco();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from customer where acno='"+id+"'");
			if(rs.next()) {
				return true;
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return false;
	}

	//depositing amount
	public void deposit() {
		int no,amt;
		boolean f;
		String pwd;
		String op="Deposit";
//		System.out.println("enter the account no:");
//		no=cin.nextInt();
		f=search(account);
		if(f) {
			System.out.println("Enter the amount to be debit:");
			amt=cin.nextInt();
			System.out.println("Enter the password:");
			pwd=cin.next();
			pwd=encrypt(pwd);
			try {
				Dbcon db=new Dbcon();
				Connection con=db.dbco();
				Statement st=con.createStatement();
				Statement st1=con.createStatement();
				ResultSet rs=st1.executeQuery("select * from customer where acno='"+account+"'");
				if(rs.next()) {
				st.executeUpdate("update customer set balance=balance+'"+amt+"'where pwd='"+pwd+"'and acno='"+account+"'");
				st.executeUpdate("insert into transaction (custid,acno,tname,tamt,balance)values('"+rs.getInt("custid")+"','"+rs.getInt("acno")+"','"+op+"','"+amt+"','"+rs.getDouble("balance")+"')");
				System.out.println(rs.getInt("custid"));
				}
				
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}else {
			System.out.println("user not found");
		}
	}

	//withdraw amount
	public void withdraw() {
		int no,amt;
		boolean f;
		String pwd;
		String op="Withdraw";
//		System.out.println("enter the account no:");
//		no=cin.nextInt();
		f=search(account);
		if(f) {
			System.out.println("Enter the amount to be Withdraw:");
			amt=cin.nextInt();
			System.out.println("Enter the password:");
			pwd=cin.next();
			pwd=encrypt(pwd);
			try {
				Dbcon db=new Dbcon();
				Connection con=db.dbco();
				Statement st=con.createStatement();
				Statement st1=con.createStatement();
				ResultSet rs=st1.executeQuery("select * from customer where acno='"+account+"'");
				if(rs.next()) {
					if(rs.getDouble("balance")>amt && rs.getDouble("balance")>1000) {
						st.executeUpdate("update customer set balance=balance-'"+amt+"'where pwd='"+pwd+"'and acno='"+account+"'");
						st.executeUpdate("insert into transaction (custid,acno,tname,tamt,balance)values('"+rs.getInt("custid")+"','"+rs.getInt("acno")+"','"+op+"','"+amt+"','"+rs.getDouble("balance")+"')");
					}
				}

			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}else {
			System.out.println("user not found");
		}

	}

	
	//account transfer
	public void Acctransfer() {
		System.out.println("Enter the amount to transfer:");
		int amt=cin.nextInt();
		System.out.println("Enter the reciever acc no:");
		int rno=cin.nextInt();
		boolean f=search(rno);
		String op="Deposit",op1="Withdraw"; 
		if(f) {
			System.out.println("Enter the password:");
			String p=cin.next();
			p=encrypt(p);
			try {				
				Dbcon db=new Dbcon();
				Connection con=db.dbco();
				Statement st=con.createStatement();
				ResultSet rs=st.executeQuery("select * from customer where acno='"+account+"'and pwd='"+p+"'");
				Statement st1=con.createStatement();
						
				if(rs.next()) {
					int id1 =rs.getInt("custid");
					double balance1=rs.getDouble("balance")-amt;
					if(rs.getDouble("balance")>amt && rs.getDouble("balance")>1000) {
					st.executeUpdate("update customer set balance=balance+'"+amt+"'where acno='"+rno+"'");
					st.executeUpdate("update customer set balance=balance-'"+amt+"'where acno='"+account+"'");
					st1.executeUpdate("insert into transaction (custid,acno,tname,tamt,balance)values('"+id1+"','"+rs.getInt("acno")+"','"+op+"','"+amt+"','"+balance1+"')");
					ResultSet rs1=st1.executeQuery("select * from customer where acno='"+rno+"'");
					rs1.next();
					int id12 = rs1.getInt("custid");
					double balance2=rs1.getDouble("balance")+amt;
					st.executeUpdate("insert into transaction (custid,acno,tname,tamt,balance)values('"+id12+"','"+rs1.getInt("acno")+"','"+op1+"','"+amt+"','"+balance2+"')");
					System.out.println("successfully transfered");
					st.close();
					st1.close();
					}
				}
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}else {
			System.out.println("No customer found with this ac no");
		}
	
	}
	
	//Mini Statement
	public void statement() {
		
		try {
			Dbcon db=new Dbcon();
			Connection con=db.dbco();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(" ");
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	private String encrypt(String pwd) {
		char[]  ch=pwd.toCharArray();
		String pd="";
		for(int i=0;i<pwd.length();i++) {
			ch[i]+=1;
			pd+=ch[i];
		}
		return(pd);
	}
	
	
	public  boolean Login(int no,String pwd) {
		pwd=encrypt(pwd);
		try {
			Dbcon db=new Dbcon();
			Connection con=db.dbco();
			Statement st=con.createStatement();
			Statement st1=con.createStatement();
			ResultSet rs=st1.executeQuery("select * from customer where acno='"+no+"' and pwd='"+pwd+"'");
			if(rs.next()) {
				account=no;
				pp=pwd;
				return true;
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return false;
	}
	
	public void transHistory() {
		try {
			Dbcon db=new Dbcon();
			Connection con=db.dbco();
			PreparedStatement st=con.prepareStatement("select * from customer where acno=?");
			st.setInt(1, account);
			ResultSet rs=st.executeQuery();
			rs.next();
			PreparedStatement st1=con.prepareStatement("select * from transaction where custid=?");
			st1.setInt(1,rs.getInt("custid")); 
			ResultSet rs1=st1.executeQuery();
			
			System.out.println("Account Statement");
			System.out.println("Name:"+rs.getString("name"));
			System.out.println("Account number:"+account);
			System.out.println("Customer id:"+rs.getInt("custid"));
			System.out.println();
			System.out.println("trans_id\ttrans_type\tamount\tbalance");
			
			while(rs1.next()) {
				System.out.println(rs1.getInt("tid")+"\t"+rs1.getString("tname")+"\t"+rs1.getDouble("tamt")+"\t"+rs1.getDouble("balance"));
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}




}
