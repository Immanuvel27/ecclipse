package abstraction;

abstract class animal{
	public abstract void sound();
	public void sleep() {
		System.out.println("sleeping");
	}
}

class cat extends animal{
	public void sound() {
		System.out.println("meow meow");
	}
}
class dog extends animal{
	public void sound() {
		System.out.println("bow bow");
	}
	public void display() {
		System.out.println("dog called");
	}
}

public class Abstract {
	public static void main(String[] args) {
		cat jimmy=new cat();
		animal puppy=new dog();//creating abstract class object
//		dog puppyDog=new dog();
		
//		jimmy.sound();
//		jimmy.sleep();
		
		puppy.sound();
		puppy.sleep();
		//while creating abstract class object it can only use the common things
//		puppy.display();    
		
	}

}
