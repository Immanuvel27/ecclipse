package accesSpecifier;

import java.util.Scanner;

public class User1 {
	Scanner cin=new Scanner(System.in);
	private String phone;
	String uname;
	String email;
	
	
	public void getInfo() {
		String uname,phone,email;
		System.out.println("REGISTER\n");
		System.out.println("enter the username:");
		uname=cin.nextLine();
		System.out.println("Enter the phone:");
		phone=cin.nextLine();
		System.out.println("enter the email:");
		email=cin.nextLine();
		this.uname=uname;
		this.phone=phone;
		this.email=email;
	}
	
	public void display() {
		String ph=this.phone;
		String lastFourDigits = ph.substring(ph.length() - 4);
		System.out.println("the username:");
		System.out.println(uname);
		System.out.println("the email:");
		System.out.println(email);
		System.out.println("the phone no:");
		System.out.println("******"+lastFourDigits);
	}
	
	public void update() {
		
	}

}
