package accesSpecifier;

import java.sql.SQLException;
import java.util.Scanner;

class Main {
	
 public static void main(String[] args) throws SQLException {
	 Scanner cin=new Scanner(System.in);
	 User u=new User();
	 int check;
	
	 do {
		 System.out.println("1:Login\n2:Register\n3:update\n0:Exit");
		 System.out.println("Enter ur choice");
		 check=cin.nextInt();
		 switch(check) {
		 case 1:{
			 		u.login();
		 		}
		 break;
		 case 2:{
			 		u.register();
		 		}
		 break;
		 
		 case 3:{
		 		u.update();
	        }
	 break;
		 case 0:{
			 System.out.println("Thank you");
		 }
		 
			 
		 }
		 
	 }while(check!=0);
 }
}
