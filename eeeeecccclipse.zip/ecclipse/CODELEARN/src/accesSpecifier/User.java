package accesSpecifier;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class User {
	Scanner cin=new Scanner(System.in);
	String username;
	private String phone;
	String email;
	
	
	public void display(String name) throws SQLException {
		try {
			Dbcon db=new Dbcon();
			Connection con=db.dbco();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from user where uname='"+name+"'");
			if(rs.next()) {
				String ph2=Decrypt2(rs.getString(3));
				String lastFourDigits = ph2.substring(ph2.length() - 4);
				System.out.println("id:"+rs.getInt(1));
				System.out.println("Name:"+rs.getString(2));
				System.out.println("email:"+rs.getString(4));
				System.out.println("phone:"+"******"+lastFourDigits);
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
//		String ph=this.phone;
//		String ph2=Decrypt2(ph);
//		String lastFourDigits = ph2.substring(ph2.length() - 4);
//		System.out.println("the username:");
//		System.out.println(username);
//		System.out.println("the email:");
//		System.out.println(email);
//		System.out.println("the phone no:");
//		System.out.println("******"+lastFourDigits);
	}
	
	
	public void register() throws SQLException {
		
		String uname,phone,email;
		System.out.println("REGISTER\n");
		System.out.println("enter the username:");
		uname=cin.nextLine();
		System.out.println("Enter the phone:");
		phone=cin.nextLine();
		System.out.println("enter the email:");
		email=cin.nextLine();
		this.username=uname;
		this.phone=phone;
		this.email=email;
		this.phone=Encrypt(phone);
		
		Dbcon db=new Dbcon();
		Connection con=db.dbco();
		Statement st=con.createStatement();
		st.executeUpdate("insert into user (uname,phone,email) values('"+this.username+"','"+this.phone+"','"+this.email+"')");
		display(uname);
	}
	
	
	public void login() throws SQLException {
		String uname,phone;
		System.out.println("Enter the username:");
		uname=cin.nextLine();
		System.out.println("enter the phone number:");
		phone=cin.nextLine();
		int log=validate(uname, phone);
		if(log==1) {
			System.out.println("login successfull");
			display(uname);
		}
		else {
			System.out.println("login unsuccessfull");
		}
		
	}
	
	private int validate(String name,String phone1) {
		String nph=Decrypt(phone1);
		int f=0;
		
		try {
			Dbcon db=new Dbcon();
			Connection con=db.dbco();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from user where uname='"+name+"'and phone='"+nph+"'");
			if(rs.next()) {
				f=1;
			}else {
				f=0;
			}
			return f;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}
	
	public void update() {
		String old,name1;
		System.out.println("Enter the username");
		name1=cin.nextLine();
		System.out.println("Enter the old phone number");
		old=cin.nextLine();
		int ch=validate(name1, old);
		if(ch==1) {
			
			
		try {
			String ph2;
			System.out.println("Enter the new phone number:");
			ph2=cin.nextLine();
			Dbcon db=new Dbcon();
			Connection con=db.dbco();
			Statement st=con.createStatement();
			String pp=Encrypt(phone);
			st.executeUpdate("update user set phone='"+pp+"'where uname='"+name1+"'");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
		}else {
			System.out.println("Enter the correct credensials");
		}
		
	}
	
	
	private String Encrypt(String phone) {
		char[] ph=phone.toCharArray();
		String ph1="";
		for(int i=0;i<10;i++) {
			ph[i]+=2;
			ph1+=ph[i];
		}
		return phone;
		
	}
	
	
	private String Decrypt(String phone) {
		char[] ph1=phone.toCharArray();
		String ph="";
		for(int i=0;i<10;i++) {
			ph1[i]+=2;
			ph+=ph1[i];
			
		}
		
		return(ph);		
		
	}
	
	
	private String Decrypt2(String phone) {
		System.out.println(phone);
		char[] ph1=phone.toCharArray();
		String ph="";
		for(int i=0;i<10;i++) {
			ph1[i]-=2;
			ph+=ph1[i];
			
		}
		
		return(ph);		
		
	}

}
