package interface1;

import java.io.*;

interface Vehicle {
	
	// all are the abstract methods.
	abstract void changeGear(int a);
	abstract void speedUp(int a);
	abstract void applyBrakes(int a);
}

class Bicycle implements Vehicle{
	
	int speed;
	int gear;
	
	// to change gear
	@Override
	public void changeGear(int newGear){
		
		gear = newGear;
	}
	
	// to increase speed
	@Override
	public void speedUp(int increment){
		
		speed = speed + increment;
	}
	
	// to decrease speed
	@Override
	public void applyBrakes(int decrement){
		
		speed = speed - decrement;
	}
	
	public void printStates() {
		System.out.println("speed: " + speed
			+ " gear: " + gear);
	}
}

class Bike implements Vehicle {
	
	int speed;
	int gear;
	
	// to change gear
	@Override
	public void changeGear(int newGear){
		
		gear = newGear;
	}
	
	// to increase speed
	@Override
	public void speedUp(int increment){
		
		speed = speed + increment;
	}
	
	// to decrease speed
	@Override
	public void applyBrakes(int decrement){
		
		speed = speed - decrement;
	}
	
	public void printStates() {
		System.out.println("speed: " + speed
			+ " gear: " + gear);
	}
	
}

class Car implements Vehicle{
	int speed;
	int gear;
	
	public void changeGear(int newGear) {
		gear=newGear;
	}
	
	public void speedUp(int newSpeed) {
		speed+=newSpeed;
	}
	
	public void applyBrakes(int decrease) {
		speed-=decrease;
	}
	public void Display() {
		System.out.println("the speed is:"+speed+"  the gear is:"+gear);
	}
	
}


class Interface {
	
	public static void main (String[] args) {
	
		// creating an inatance of Bicycle
		// doing some operations		
		Bicycle bicycle = new Bicycle();
		bicycle.changeGear(2);
		bicycle.speedUp(3);
		bicycle.applyBrakes(1);
		
		System.out.println("Bicycle present state :");
		bicycle.printStates();
		
		// creating instance of the bike.
		Bike bike = new Bike();
		bike.changeGear(1);
		bike.speedUp(4);
		bike.applyBrakes(3);
		
		System.out.println("Bike present state :");
		bike.printStates();
		
		
		//car instance
		Car car=new Car();
		car.changeGear(3);
		car.speedUp(50);
		car.applyBrakes(10);
		
		System.out.println("car state");
		car.Display();
	}
}
