package multithreading;


class counter{
	int count=0;
	public void increase() {
		count++;
	}
}
public class Syncornized {
 public static void main(String[] args) throws Exception {
	 counter c=new counter();
	 
	 Thread t1=new	Thread(new Runnable() {
		
		@Override
		public void run() {
			// TODO Auto-generated method stub
			for(int i=0;i<100000;i++) {
				c.increase();
			}
			
		}
	});
	 Thread t2=new	Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				for(int i=0;i<100000;i++) {
					c.increase();
				}
				
			}
		});
	 
	 

	 
	 
	 t1.start();
	 t2.start();
	 
	 t1.join();
	 t2.join();
	 
	 System.out.println("counter:"+c.count);
	 
}
}
