package multithreading;
public class Priority {
	public static void main(String[] args) {
		Thread t1=new Thread(()->{
			for(int i=0;i<10;i++) {
				System.out.println("hi");
				try {
					Thread.sleep(1000);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}); 
		Thread t2=new Thread(()->{
			for(int i=0;i<10;i++) {
				System.out.println("hello");
				try {
					Thread.sleep(1000);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		);
		//setting priorities
//		t1.setPriority(1);
//		t2.setPriority(10);
		t1.setPriority(Thread.MIN_PRIORITY);
		t2.setPriority(Thread.MAX_PRIORITY);
		
		
		
		//checking priorities for the threads
		System.out.println(t1.getPriority());
		System.out.println(t2.getPriority());
		t1.start();
		try {
			Thread.sleep(10);
		} catch (Exception e) {
			// TODO: handle exception
		}
		t2.start();
		
		
	}


}


