package multithreading;


class hi implements Runnable{
	public void run() {
	for(int i=0;i<5;i++) {
		System.out.println("hii");
		try {
			Thread.sleep(1000);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	}
}
class hello implements Runnable{
	public void run() {
		for(int i=0;i<5;i++) {
			System.out.println("hello");
			try {
				Thread.sleep(1000);
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		}
}
public class ThreadDemo{
	public static void main(String[] args) {
		hi obj=new hi();
		hello obj2=new hello();
//		obj.start();
//		obj2.start();
		Thread t1=new Thread(obj);
		Thread t2=new Thread(obj2);
		t1.start();
		t2.start();
	}
}
