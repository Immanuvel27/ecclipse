package multithreading;



public class Thread123 {
	public static void main(String[] args) {
		Thread t1=new Thread(()->{
			for(int i=0;i<5;i++) {
				System.out.println("hi");
			}
		}); 
		
		Thread t2=new Thread(()->{
			for(int i=0;i<5;i++) {
				System.out.println("hello");
			}
		}
		);
		
		t1.start();
		try {
			Thread.sleep(10);
		} catch (Exception e) {
			// TODO: handle exception
		}
		t2.start();
	}


}


