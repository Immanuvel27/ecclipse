package multithreading;

import javax.rmi.CORBA.Tie;

public class Alive {

	public static void main(String[] args) throws InterruptedException {
		Thread t1=new Thread(()->{
			for(int i=0;i<5;i++) {
				System.out.println("hi");
			}
		}); 
		
		Thread t2=new Thread(()->{
			for(int i=0;i<5;i++) {
				System.out.println("hello");
			}
		}
		);
		
		
		
		t1.start();
		try {
			Thread.sleep(10);
		} catch (Exception e) {
			// TODO: handle exception
		}
		t2.start();
		
		System.out.println(t2.isAlive());//checks the t1 thread is live or not
		
		
		//wait to main thread to complete the task
		t1.join();
		t2.join();
		System.out.println(t1.isAlive());//checks the t1 thread is live or not  it returns false because
		//the t1 joins the main thread
		System.out.println("good bye");
	}
	
	
	



}
