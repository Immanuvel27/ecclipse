package multithreading;

import java.util.Scanner;

public class test {
	public static int convert(String s) {
		
		int num=0;
		for(int i=0;i<s.length();i++) {
			 num = num * 10 + ((int)s.charAt(i) - 48);
			
		}
		return(num);
		
	}
public static void main(String[] args) {
	Scanner cin=new Scanner(System.in);
	String ch;
	int sum=0;
	do {
		System.out.println("Enter the number to add:");
		ch=cin.next();
		if(!ch.equals("x")) {
			int num=convert(ch);
			sum+=num;
		}
		
		
	} while (!ch.equals("x"));
	
	System.out.println("the sum is:"+sum);
}
}
