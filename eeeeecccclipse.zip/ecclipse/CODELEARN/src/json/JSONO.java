package json;
import java.util.ArrayList;
import java.util.Scanner;

import org.json.*;

public class JSONO {

	public static void main(String[] args) {
		Scanner cin=new Scanner(System.in);
		JSONObject object=new JSONObject();
		JSONObject obj=new JSONObject();
		object.put("name", "imman");
		object.put("location", "coimbatore");	
		
		ArrayList<String> list=new ArrayList<String>();
//		list.add("c");
//		list.add("mern");
//		list.add("sql");
		int ch;String str;
		do {
			System.out.println("do you want to enter more course: 1:yes 0:no:");
			ch=cin.nextInt();
			switch (ch) {
			case 1:
				System.out.println("Enter the course");
				str=cin.next();
				if(str!="") {
				list.add(str);}
				break;

			default:
				break;
			}
		} while (ch!=0);
		
		obj.put("sno", 1);
		obj.put("details", object);
		obj.put("courses", list);
		
		System.out.println(obj);
		
		
		

	}

}
