package view;

import java.util.Scanner;

import Controller.eventBooking;
import model.bookingPojo;

public class bookEvents {
	eventBooking eventBook=new eventBooking();
	Scanner cin=new Scanner(System.in);
	
	
	public void book() {
		System.out.println("Enter the Event id to book:");
		int eventid=cin.nextInt();
		System.out.println("Enter the venue:");
		String venue=cin.next();
		System.out.println("Enter the date(DD:MM:YYYY):");
		String date=cin.next();
		bookingPojo book=new bookingPojo(venue, date);
		boolean result=eventBook.bookEvents(book,eventid);
		if(result) {
			System.out.println("Requested wait for response");
		}else {
			
			book();
		}
		
		
	}

}
