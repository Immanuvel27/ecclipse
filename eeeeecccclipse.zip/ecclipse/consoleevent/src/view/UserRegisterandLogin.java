package view;

import java.util.Scanner;
import model.userPojo;
import Controller.*;

public class UserRegisterandLogin {
	Scanner cin=new Scanner(System.in);
	AuthenticateUser user=new AuthenticateUser();
	
	public void register() {
		String name,email,password,phone,address;
		System.out.println("Enter the name:");
		name=cin.next();
		System.out.println("Enter the email:");
		email=cin.next();
		System.out.println("Enter the password:");
		password=cin.next();
		System.out.println("Enter the phone:");
		phone=cin.next();
		System.out.println("Enter the address:");
		address=cin.next();
		userPojo customer=new userPojo(name, email, password, phone, address);
		boolean result=user.registeringUser(customer);
		
		if(result) {
			System.out.println("User Registered Successfully");
			
		}else {
			System.out.println("User not Registered");
		}
		
	}
	
	public boolean login() {
		
		System.out.println("Enter the email:");
		String email=cin.next();
		System.out.println("Enter the password:");
		String password=cin.next();
		userPojo customer=new userPojo(email, password);
		boolean result=user.login(customer);
		return result;
	}

}
