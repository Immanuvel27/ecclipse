package view;

import java.util.Scanner;

import Controller.AuthenticateAdmin;
import model.userPojo;

public class Loginadmin {
	AuthenticateAdmin admin2=new AuthenticateAdmin();
	Scanner cin = new Scanner(System.in);
	
	public boolean loginOperation() {
		
		System.out.println("Enter the email:");
		String email=cin.next();
		System.out.println("Enter the password:");
		String password=cin.next();
		userPojo admin1=new userPojo(email, password);
		boolean result=admin2.adminlogin(admin1);
		
		return result;

	}

}
