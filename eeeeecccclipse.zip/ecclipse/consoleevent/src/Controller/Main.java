package Controller;
import java.util.Scanner;
import view.Loginadmin;
import view.UserRegisterandLogin;

public class Main {
	public static int uid;
	
	public static void main(String[] args) {
		Scanner cin=new Scanner(System.in);
		UserRegisterandLogin user=new UserRegisterandLogin();
		customerOperation customer=new customerOperation();
		Loginadmin admin1=new Loginadmin();
		
		
		System.out.println(" ----------------------------------");
		System.out.println(" |      Event Management system   |");
		System.out.println(" ----------------------------------");
		int userchoice;
		do {
			System.out.println();
			System.out.println("1:Customer\t2:Admin\t");
			System.out.println("Enter your choice:");
			userchoice=cin.nextInt();
			switch (userchoice) {
			case 1:
				int customerChoice;
				do {
					System.out.println("Customer-Page\n");
					System.out.println("1:Register\t2:Login\t0:Exit");
					System.out.println("Enter your choice:");
					customerChoice=cin.nextInt();
					switch (customerChoice) {
					case 1:
						user.register();						
						break;
					case 2:
						boolean result=user.login();
						if(result) {
							customer.displayCustomerOperation();
						}

					default:
						break;
					}
					
				} while (customerChoice!=0);				
				break;
			case 2:
				boolean result=admin1.loginOperation();
				if(result) {
					adminOperations admin=new adminOperations();
					admin.displayAdmin();
				}
				
				break;
			case 0:
				uid=-1;
				break;

			default:
				break;
			}
		} while (userchoice!=0);
	}
}
