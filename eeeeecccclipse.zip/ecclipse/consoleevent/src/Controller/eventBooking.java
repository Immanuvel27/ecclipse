package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import model.bookingPojo;

public class eventBooking {
//	view.bookEvents b=new view.bookEvents();
public boolean bookEvents(bookingPojo book,int id) {
	boolean result=false,flag = false;
	int n = 0;
	try {
		Connection con=dbconnection.dbco();
		PreparedStatement stmt1=con.prepareStatement("select eid from events");
		PreparedStatement stmt=con.prepareStatement("insert into booking (venue,date,userid,eventid) values (?,?,?,?)");
		stmt.setString(1, book.getVenue());
		stmt.setString(2,book.getDate());
		stmt.setInt(3,Main.uid);
		stmt.setInt(4,id);
		ResultSet rs=stmt1.executeQuery();
		while(rs.next()) {
			if(rs.getInt("eid")==id) {
				flag=true;				
			}
		}
		
		if(flag==true) {
		n=stmt.executeUpdate();
		}
		
		if(n!=0) {
			result=true;
			
		}else {
			result=false;
			
		}
		con.close();
		
	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}
	

	
	return result;
	
}

}
