package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


import model.userPojo;

public class AuthenticateUser {
	
	public boolean registeringUser(userPojo customer) {
		boolean result=false;
		try {
			Connection con=dbconnection.dbco();
			PreparedStatement stmt=con.prepareStatement("insert ignore into user (name,email,password,phone,address,usertype) values(?,?,?,?,?,?)");
			stmt.setString(1, customer.getName());
			stmt.setString(2, customer.getEmail());
			stmt.setString(3, customer.getPassword());
			stmt.setString(4, customer.getPhone());
			stmt.setString(5, customer.getAddress());
			stmt.setString(6, "customer");
			int n=stmt.executeUpdate();
			if(n==1) {
				result=true;
			stmt.close();
			con.close();
			}else {
				result=false;
			}
				
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		return result;
	}
	
	
	
	public boolean login(userPojo customer) {
		boolean result=false;
		try {
			Connection con;
			con=dbconnection.dbco();
			PreparedStatement stmt=con.prepareStatement("select * from user where email=? and password=?and usertype=?");
			stmt.setString(1, customer.getEmail());
			stmt.setString(2, customer.getPassword());
			stmt.setString(3, "customer");
			ResultSet rs=stmt.executeQuery();
			if(rs.next()) {
				Main.uid=rs.getInt("id");
				result=true;
			}
			
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return result;
		
	}

}
