package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import model.userPojo;

public class AuthenticateAdmin {

	public boolean adminlogin(userPojo admin) {
		boolean result=false;
		try{
			Connection con=dbconnection.dbco();
			PreparedStatement stmt=con.prepareStatement("select * from user where email=? and password=?and usertype=?");
			stmt.setString(1, admin.getEmail());
			stmt.setString(2, admin.getPassword());
			stmt.setString(3, "admin");
			ResultSet rs=stmt.executeQuery();
			if(rs.next()) {
				result=true;
			}


		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return result;
	}
}
