package Controller;

import java.util.Scanner;

import view.bookEvents;

public class customerOperation {
	adminOperations ad=new adminOperations();
	bookEvents book=new bookEvents();
	
	public void displayCustomerOperation() {
		Scanner cin=new Scanner(System.in);
		int ch1;
		do {System.out.println("1:View-Events\t2:Book-events\t3:cancel-booking\t0:Exit");
		System.out.println("Enter your choice:");
		ch1=cin.nextInt();
		switch (ch1) {
		case 1:
			ad.viewEvents();
			break;
		case 2:
			ad.viewEvents();
			book.book();
			
			break;

		default:
			break;
		}
		}while(ch1!=0);
		
	}


}

