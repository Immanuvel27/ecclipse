package model;

public class bookingPojo {
	private String venue;
	private String date;
	public String getVenue() {
		return venue;
	}
	public void setVenue(String venue) {
		this.venue = venue;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	public bookingPojo(String venue,String Date) {
		
		this.venue=venue;
		this.date=Date;
	}
	

}
