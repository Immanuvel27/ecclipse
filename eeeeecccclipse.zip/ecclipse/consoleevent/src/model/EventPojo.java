package model;

public class EventPojo {
	private String ename;
	private double price;
	private int rating;


	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}

	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}

	public EventPojo(String ename,double price,int rating) {
		this.ename=ename;
		this.price=price;
		this.rating=rating;
	}




}
