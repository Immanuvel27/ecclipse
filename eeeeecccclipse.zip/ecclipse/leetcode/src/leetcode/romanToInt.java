package leetcode;

import java.util.Scanner;

class romanToInt {
	public static void main(String[] args) {
		
		 Scanner cin=new Scanner(System.in);
	         String str;
	         System.out.println("Enter the Roman letters:");
	         str=cin.next();
	         int number=romanToInt(str);
	         System.out.println("The number is:"+number);
		
	}
	
	
public static int romanToInt(String s) {
        
        int len=s.length();
        int sum=0;
        char[] ch=s.toCharArray(); 
        for(int i=len-1;i>0;i--){
            if(ch[i]=='I'||ch[i]=='i'){
                sum+=1;
            }else if(ch[i]=='V'||ch[i]=='v'){
                if(ch[i-1]=='I'||ch[i]=='i'){
                sum+=4;
                i--;
                }else{
                    sum+=5;
                }
            }else if(ch[i]=='X'||ch[i]=='x'){
                sum+=10;
            }else if(ch[i]=='L'||ch[i]=='l'){
                sum+=50;
            }
            else if(ch[i]=='C'||ch[i]=='c'){
                if(ch[i-1]=='X'||ch[i-1]=='x'){
                    sum+=90;
                    i--;
                }else{
                sum+=100;
                }
            }else if(ch[i]=='D'||ch[i]=='d'){
                sum+=500;
            }else if(ch[i]=='M'||ch[i]=='m'){
                if(ch[i-1]=='C'||ch[i-1]=='c'){
                    sum+=900;
                    i--;
                }else{
                    sum+=1000;
                }
                
            }
        }

        
            if(ch[0]=='I'||ch[0]=='i'){
                sum+=1;
            }else if(ch[0]=='V'||ch[0]=='v'){
                
                    sum+=5;
                
            }else if(ch[0]=='X'||ch[0]=='x'){
                sum+=10;
            }else if(ch[0]=='L'||ch[0]=='l'){
                sum+=50;
            }
            else if(ch[0]=='C'||ch[0]=='c'){
               
                sum+=100;
                
            }else if(ch[0]=='D'||ch[0]=='d'){
                sum+=500;
            }else if(ch[0]=='M'||ch[0]=='m'){
               
                    sum+=1000;
                }
                
            
        

        return(sum);
    }
};
