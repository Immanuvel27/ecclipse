package leetcode;

import java.util.*;

public class stringToInt {
	public static void main(String[] args) {
		Scanner cin=new Scanner(System.in);
		String s;
		int n=0,num;
		System.out.println("Enter the String:");
		s=cin.next();
		char[] ch=s.toCharArray();
		for(int i=0;i<s.length();i++) {
			num=0;
			//checking the char is a number or not
			if(ch[i]>=48 && ch[i]<=57) {
				n=n*10+(ch[i]-48);//assigning n to a number
			}
		}
		
		System.out.println("the number is:");
		System.out.println(n);
	}

}
