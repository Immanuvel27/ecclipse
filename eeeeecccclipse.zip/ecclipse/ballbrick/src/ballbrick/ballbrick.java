package ballbrick;

import java.util.Scanner;

public class ballbrick {
	static int ballcount;
	static int ballPos;

	//	playing game
	public static void playGame(char[][] game,int n) {
		Scanner cin=new Scanner(System.in);
		String path;int check;
		do {
			System.out.println("enter the path"+"\n"+"ST for Straight\nLD for left diagonal\nRD for right diagonal");
			path=cin.next();
			switch (path) {
			case "ST":
				for(int i=n-1;i>=0;i--) {

					if(game[i][ballPos]=='1') {
						game[i][ballPos]=' ';
						break;
					}


				}

				break;
			case "LD": 
				int temp=ballPos;
				int dir=0;
				for(int i=n-1;i>=ballPos;i--) {
					if(game[i][temp--]=='W') {
					dir=i;	
					}
				}
				for(int i=0;i<n;i++) {
					if(game[dir][i]=='1') {
						game[dir][i]=' ';
						
						game[n-1][i]='0';
						game[n-1][ballPos]='G';
						ballPos=i;
						break;
					}
					
				}
					
				break;
				
			case "RD":
				int t=n-1;
				int dir1=0;
				for(int i=ballPos;i<=n-1;i++) {
					if(game[i][t--]=='W') {
						dir1=i;
					}
				}
				for(int i=n-1;i>=0;i--) {
					if(game[dir1][i]=='1') {
						game[dir1][i]=' ';
						game[n-1][i]='0';
						game[n-1][ballPos]='G';
						ballPos=i;
						break;
					}
					if(game[dir1][i]=='W') {
						ballcount--;
						game[n-1][(n-1)/2]='0';
						ballPos=(n-1)/2;
					}
				}
					  
				break;

			default:
				break;
			}
			matPrint(game, n);
			System.out.println("Ball Count:"+ballcount);
			System.out.println("want to continue 1 or 0:");
			check=cin.nextInt();

		} while (check!=0);
		
		

	}
	//setting brick
	public static void setBrick(char[][] game,int n) {
		Scanner cin=new Scanner(System.in);
		int x,y;
		char z;
		int check;
		do {
			System.out.println("enter 1 to continue 0 to stop:");
			check=cin.nextInt();
			switch (check) {
			case 1:{System.out.println("Enter the brick's posistion and ");
			x=cin.nextInt();
			y=cin.nextInt();
			z=cin.next().charAt(0);

			for(int i=0;i<n;i++) {
				for(int j=0;j<n;j++) {
					game[x][y]=z;
				}
			}
			}

			break;
			case 0:
				System.out.println("Thank You!!!");
				break;

			default:
				break;
			}

		} while (check!=0);
		System.out.println("enter the ball count:");
		ballcount=cin.nextInt();

	}

	//setting the wall and ground
	public static void setmat(char[][] game,int n) {
		for(int i=0;i<n;i++) {
			for(int j=0;j<n;j++) {
				
				if(i==n-1) {
					game[i][j]='G';
				}
				
				if(i==0||j==0||j==n-1) {
					game[i][j]='W';
				}
				
				if(i==n-1) {
					game[i][(n-1)/2]='0';
				}
			}
		}
	}


	//printing matrix
	public static void matPrint(char[][] arr,int n) {
		for(int i=0;i<n;i++) {
			for(int j=0;j<n;j++) {
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		Scanner cin=new Scanner(System.in);
		System.out.println("enter the size of array:");
		int n=cin.nextInt();
		char[][] game = new char[n][n];
		int check;
		ballPos=(n-1)/2;
		setmat(game, n);
		setBrick(game, n);
		matPrint(game, n);
		playGame(game, n);
		System.out.println("Ball Count:"+ballcount);



	}

}
