package event;

public class Booking extends Event{
	public String venue;

	public String getVenue() {
		return venue;
	}

	public void setVenue(String venue) {
		this.venue = venue;
	}
	
	public void booking(){
		
	}
}
