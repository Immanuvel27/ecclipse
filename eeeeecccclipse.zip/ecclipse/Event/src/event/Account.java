package event;

public abstract class Account {
	
abstract boolean login();
abstract void logout();

}
