package Evaluation;

import java.util.Scanner;

public class Q2 {

	public static String removeDup(String str,int n) {
		char[] ch = str.toCharArray();
		int count=1;
		String str1="";
		for(int i=0;i<n;i++) {
			count=1;
			if(ch[i]!='*') {
				for(int j=i+1;j<n;j++) {

					if(ch[i]==ch[j]) {
						ch[j]='*';
						count++;

					}
				}
				str1+=ch[i];
				str1+=count;

			}


		}
		return(str1);
	}

	public static void main(String[] args) {
		Scanner cin=new Scanner(System.in);
		String str;
		System.out.println("Enter the string:");
		str=cin.next();
		int n=str.length();
		String st1=removeDup(str,n);
		System.out.println("The result:");
		System.out.println(st1);
	}

}
