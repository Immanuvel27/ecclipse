package Evaluation;

import java.util.Scanner;

public class Q1 {
	public static int countWords(String str) {
		int count=1;
		char[] ch = str.toCharArray();
		for(int i=0;i<str.length();i++) {
			if(ch[i]==' ') {
				count++;
			}
		}
		return(count);
	}


	public static void main(String[] args) {
		String str,choice;
		Scanner cin=new Scanner(System.in);
		System.out.println("Enter the string:");
		str=cin.nextLine();
		System.out.println("Enter the choice odd or even");
		choice=cin.next();
		//count no of words in string
		int noWords=countWords(str);

		String []st1=new String[noWords];
		String s="";
		char[] ch = str.toCharArray();
		int k=0,l=0;
		for(int i=0;i<str.length();i++) {
			if(ch[i]==' ') {
				for(int j=k;j<i;j++) {
					s+=ch[j];
					
				}
				k=i;
				st1[l]=s;
				l++;
				s="";
			}			
			
		}
		for(int i=str.length()-1;i>k-1;i--) {
			if(ch[i]==' ') {
				for(int z=i+1;z<str.length();z++) {
					s+=ch[z];
					st1[l]=s;
				}
			}
//			System.out.println(ch[i]);
		}
		
		

		for(int i=0;i<noWords;i++) {
			if(choice.equals("odd")) {
				if(i%2==0) {
					String str1="";
					char temp;
					char[] ch1= st1[i].toCharArray();
					
					 for(int j=st1[i].length()-1;j>=0;j--) {
						 
						 str1+=ch1[j];
						 
					 }
					 st1[i]=str1;
				}
			}else{
				if(i%2!=0) {
					String str1="";
					char temp;
					char[] ch1= st1[i].toCharArray();
					
					 for(int j=st1[i].length()-1;j>=0;j--) {
						 
						 str1+=ch1[j];
						 
					 }
					 st1[i]=str1;
				}
			} 
		}
		
		for(int i=0;i<noWords;i++) {
			System.out.print(st1[i]+" ");
		}
		System.out.println("no of words:"+noWords);


	}
}
