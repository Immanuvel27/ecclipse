package zcoin;

import java.util.Scanner;

import zcoin.Dbcon;

public class main {
	static Scanner cin=new Scanner(System.in);
	static Dbcon db=new Dbcon();
	public static void main(String[] args) {
		System.out.println("Zcoin application");
		
		int choice;
		do {System.out.println("1:agent\n2:user\n0:Exit");
			System.out.println("Enter the choice:");
			choice=cin.nextInt();
			switch (choice) {
			case 1:
			{String email,pwd;
			System.out.println("Enter the email:");
			email=cin.next();
			System.out.println("Enter the password:");
			pwd=cin.next();

			if(email.equals("admin@gmail.com") && pwd.equals("admin@123")) {
				admin admin=new admin();

				int ch;

				do {
					System.out.println("1:approval notification for user\n2:approving\n0:Exit");
					System.out.println("Enter your choice:");
					ch=cin.nextInt();
					switch (ch) {
					case 1:
						admin.aprrovalcheck();

						break;
					case 2:
						admin.approval();
						break;
					

					default:
						break;
					}

				} while (ch!=0);




			}
			else {
				System.out.println("You are not authenticated as admin");
			}

			}
			break;
			case 2:
			{
				System.out.println("Welcome user");
				user u=new user();
				int ch;
				do {
					System.out.println("1:Register\n2:Login\n0:Exit");
					System.out.println("Enter your choice:");
					ch=cin.nextInt();
					switch (ch) {
					case 1:
						u.register();
						break;

					case 2:{
						boolean f=u.login();
						if(f) {
							user u1=new user();
							System.out.println("login success");

						}else {
							System.out.println("you have not approved to login");
						}

					}
					break;
					case 0:{
						System.out.println("thankyou");
					}
					break;

					default:
						break;
					}
				} while (ch!=0);
			}
			break;
			case 0:{
				System.out.println("thankyou");
			}
			break;

			default:
				break;
			}

		} while (choice!=0);



	}
}
