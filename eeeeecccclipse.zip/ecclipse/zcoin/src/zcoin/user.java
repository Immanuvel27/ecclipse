package zcoin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import zcoin.Dbcon;

public class user {
	
	private String fullname;
	private String emailid;
	private String mobileno;
	private String h_id;
	private String password;
	private float RCdeposit;
	
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public String getH_id() {
		return h_id;
	}
	public void setH_id(String h_id) {
		this.h_id = h_id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public float getRCdeposit() {
		return RCdeposit;
	}
	public void setRCdeposit(float rCdeposit) {
		RCdeposit = rCdeposit;
	}
	
	public user() {
		this.RCdeposit=100;
	}
	
	public void register() {
		System.out.println("Enter trhe full name:");
		this.fullname=main.cin.next();
		System.out.println("Enter trhe Email id:");
		this.emailid=main.cin.next();
		System.out.println("Enter trhe mobile no:");
		this.mobileno=main.cin.next();
		System.out.println("Enter trhe Aadharno:");
		this.h_id=main.cin.next();
		System.out.println("Enter trhe Password:");
		this.password=main.cin.next();
		
		try {
			Dbcon db=new Dbcon();
			Connection con=db.dbco();
			Statement stmt=con.createStatement();
			stmt.executeUpdate("insert into user(fullname,email,mobileno,hid,password) values('"+this.fullname+"','"+this.emailid+"','"+this.mobileno+"','"+this.h_id+"','"+this.password+"')");
//			Connection con=main.db.dbco();
//				
//			stmt.setString(1,this.fullname);
//			stmt.setString(2,this.emailid);
//			stmt.setString(3, this.mobileno);
//			stmt.setString(4, this.h_id);
//			stmt.setString(5, this.password);
			System.out.println("Registered succesfully");
			stmt.close();
			con.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	
	public boolean login() {
		boolean f=false;
		String email,pwd;
		System.out.println("Enter the email:");
		email=main.cin.next();
		System.out.println("Enter the password");
		pwd=main.cin.next();
		
		try {
			Dbcon db=new Dbcon();
			Connection con=db.dbco();			
			PreparedStatement stmt=con.prepareStatement("select * from user where email=? and password=? and status=? ");
			stmt.setString(1, email);
			stmt.setString(2, pwd);
			stmt.setString(3, "approved");
			ResultSet rs=stmt.executeQuery(); 
			if(rs.next()) {
				f=true;
			}else {
				f=false;
			}
			stmt.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return(f);
		
	}
	
	

}
