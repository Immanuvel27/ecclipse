package zcoin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.mysql.cj.protocol.FullReadInputStream;

public class admin{

	public void aprrovalcheck() {
		try {
			Dbcon db=new Dbcon();
			Connection con=db.dbco();
			Statement stmt=con.createStatement();
			String s="pending";
			ResultSet rs= stmt.executeQuery("select fullname,email from user where status='"+s+"'");
			System.out.println("Fullname          email");
			while(rs.next()) {
				
				System.out.println(rs.getString("fullname")+"    "+rs.getString("email"));
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	public void approval() {
		System.out.println("Enter the email to approve:");
		String email=main.cin.next();
		String s="approved";
		try {
			Dbcon db=new Dbcon();
			Connection con=db.dbco();
			Statement st=con.createStatement();
			Statement st1=con.createStatement();
			PreparedStatement stmt=con.prepareStatement("update user set status='"+s+"' where email=?");
			stmt.setString(1, email);
			ResultSet rs=st1.executeQuery("select * from user where email='"+email+"'");
			rs.next();
			int i=stmt.executeUpdate();
			st.executeUpdate("update user set zid=1000+'"+rs.getInt("id")+"");
			System.out.println(email+" user approved");
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
