package l2test;

public class Imman{
	
	public void display() {
		System.out.println("parent Displayed");
	}

}

class Child extends Imman{
	public void display() {
		System.out.println("Children called");

	}
}


class Main{
	
	public static void main(String[] args) {
		Child child=new Child();
		
		
		child.display();
	}
}



