package l2test;

import java.util.Scanner;

public class Student {
	String name;
	int roll_no;
	Student(int n,String name){
		this.name=name;
		this.roll_no=n;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner cin=new Scanner(System.in);
		System.out.println("Enter the roll no:");
		int n=cin.nextInt();
		System.out.println("Enter the name:");
		String name=cin.next();
		Student student=new Student(n,name);
		System.out.println(student.roll_no);
		System.out.println(student.name);

	}

}
