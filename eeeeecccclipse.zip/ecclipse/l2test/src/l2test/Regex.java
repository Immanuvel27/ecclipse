package l2test;

import java.util.regex.Pattern;

public class Regex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String p="^(?=(?:\\D*\\d){2})(?=(?:[^a-z]*[a-z]){2})";
		String s="12an";
		boolean b=Pattern.matches(p, s);
		System.out.println("result:"+b);

	}

}
