package l2test;

public class Rectangle {
	 int l,b;
	 Rectangle(int a,int b){
		 this.l=a;
		 this.b=b;
	 }
	 int area() {
		 return(l*b);
	 }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle r=new Rectangle(4, 5);
		System.out.println("Area of rectangle 1:\n"+r.area());
		Rectangle r2=new Rectangle(5, 8);
		System.out.println("Area of rectangle 2:\n"+r2 .area());

	}

}
