package com.login;

public class user {
	int id;
	String name;
	String phone;
	String in_time;
	String out_time;
	String doc_time;
	String 	tot_time;
	String w_time;
	String status;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getIn_time() {
		return in_time;
	}
	public void setIn_time(String in_time) {
		this.in_time = in_time;
	}
	public String getOut_time() {
		return out_time;
	}
	public void setOut_time(String out_time) {
		this.out_time = out_time;
	}
	public String getDoc_time() {
		return doc_time;
	}
	public void setDoc_time(String doc_time) {
		this.doc_time = doc_time;
	}
	public String getTot_time() {
		return tot_time;
	}
	public void setTot_time(String tot_time) {
		this.tot_time = tot_time;
	}
	public String getW_time() {
		return w_time;
	}
	public void setW_time(String w_time) {
		this.w_time = w_time;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}


	


}
