package com.login;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class logout
 */
@WebServlet("/logout")
//public class logout extends HttpServlet {
//	private static final long serialVersionUID = 1L;
// 
//	
//	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		 request.getSession().invalidate();
//	        response.sendRedirect(request.getContextPath() + "/Index.html");
//	}
//
//}
public class logout extends HttpServlet {

//    public void service(HttpServletRequest rq, HttpServletResponse rs) throws IOException, ServletException {
//        try {
//            HttpSession ss = rq.getSession(false);
//            if (ss.getAttribute("email") == null) {
//                rs.sendRedirect("/");
//            }
//
//            rs.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
//            rs.addHeader("Cache-Control", "post-check=0, pre-check=0");
//            rs.setHeader("Pragma", "no-cache");
//            rs.setDateHeader("Expires", 0);
//            HttpSession session = rq.getSession(false);
//            session.setAttribute("email", null);
//            session.invalidate();
//            rs.sendRedirect("/");
//        } catch (Exception exp) {
//            //  rs.sendRedirect("/");
//            RequestDispatcher dd = rq.getRequestDispatcher("/");
//            dd.forward(rq, rs);
//        }
//
//    }
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
  
        // Get the print writer object to write into the response
        PrintWriter out = response.getWriter();
  
        // Set the content type of response to "text/html"
        response.setContentType("text/html");
  
        // For understanding purpose, print the session object in the console before
        // invalidating the session.
        System.out.println("Session before invalidate: "+ request.getSession(false));
  
        // Invalidate the session.
        request.getSession(false).invalidate();
  
        // Print the session object in the console after invalidating the session.
        System.out.println("Session after invalidate: "+ request.getSession(false));
  
        // Print success message to the user and close the print writer object.
//        out.println("Thank you! You are successfully logged out.");
//        out.close();
        response.sendRedirect("Index.html");
    }
}
