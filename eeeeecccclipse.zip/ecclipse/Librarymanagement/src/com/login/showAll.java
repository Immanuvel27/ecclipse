package com.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/showAll")
public class showAll extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			int i=0;
			PrintWriter out=response.getWriter();
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","Immanuvel*27");
			Statement st=con.createStatement();
			Statement st2=con.createStatement();
			ResultSet rs=st.executeQuery("select * from patient p,statusmsg s where p.id=s.id");
			ResultSet rs1=st2.executeQuery("select count(p.id) from patient p,statusmsg s where p.id=s.id");
			
			rs1.next();
			int n=rs1.getInt("count(p.id)");
			user u[]=new user[n];
			i=0;
			out.println("<!DOCTYPE html>\r\n" + 
					"<html>\r\n" + 
					"<head>\r\n" + 
					"<link\r\n" + 
					"	href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css\"\r\n" + 
					"	rel=\"stylesheet\">\r\n" + 
					"<script\r\n" + 
					"	src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js\"></script>\r\n" + 
					"<meta charset=\"UTF-8\">\r\n" + 
					"<title>Insert title here</title>\r\n" + 
					"</head>\r\n" + 
					"<body>"
					+ "<h2 class=\"text-center\" style=\"margin-top:10%\">Patient Details</h2>\r\n" + 
					"	<div class=\" w-75 container text-center mt-2\">\r\n" + 
					"		<table class=\"table table-bordered text-center\">\r\n" + 
					"			<tr>\r\n" + 
					"				<th>ID</th>\r\n" + 
					"				<th>Name</th>\r\n" + 
					"				<th>Phone</th>\r\n" + 
					"				<th>IN-Time</th>\r\n" + 
					"				<th>Out-Time</th>\r\n" + 
					"				<th>Doctor-time</th>\r\n" + 
					"				<th>Total time taken</th>\r\n" + 
					"				<th>Waiting time</th>\r\n" + 
					"				<th>Status</th>\r\n" + 
					"			</tr>");
			while(rs.next()) {				
			out.println("<tr>\r\n" + 
					"				<td>"+rs.getInt("id") +"</td>\r\n" + 
					"				<td>"+rs.getString("name")+"</td>\r\n" + 
					"				<td>"+rs.getString("phone")+"</td>\r\n" + 
					"				<td>"+rs.getString("intime")+"</td>\r\n" + 
					"				<td>"+rs.getString("outtime")+"</td>\r\n" + 
					"				<td>"+rs.getString("doctortime")+"</td>\r\n" + 
					"				<td>"+rs.getString("total_time")+"</td>\r\n" + 
					"				<td>"+rs.getString("waitingtime")+"</td>\r\n" + 
					"				<td>"+rs.getString("message")+"</td>\r\n" + 
					"			</tr>");
				
			}
			out.println("</table>\r\n"
					+ "<button class=\"btn btn-primary mt-3 text-center \" onclick=\"window.location.href='dash.html'\">Back to home</button>" + 
					"	</div>\r\n" + 
					"</body>\r\n" + 
					"</html>");
			
			
//			for(int i1=0;i1<n;i1++)
//			{
//				u[i1].getId();
//				u[i1].getName();
//				u[i1].getPhone();
//				u[i1].getIn_time();
//				u[i1].getOut_time();
//				u[i1].getDoc_time();
//				u[i1].getTot_time();
//				u[i1].getW_time();
//				u[i1].getStatus();
//			}
			request.setAttribute("patient",u); 			
//				request.setAttribute("id"+i, u[i].id);
//				request.setAttribute("name", u[].name);
//				request.setAttribute("phone", u.phone);
//				request.setAttribute("intime", u.in_time);
//				request.setAttribute("outtime", u.out_time);
//				request.setAttribute("doctime", u.doc_time);
//				request.setAttribute("tottime", u.tot_time);
//				request.setAttribute("waitingtime", u.w_time);
//				request.setAttribute("status", u.status);
//			RequestDispatcher rt=request.getRequestDispatcher("findAll.jsp");
//			rt.forward(request, response);	
			
			}
			
		 catch (Exception e) {
			e.printStackTrace();
		}
	}

}
