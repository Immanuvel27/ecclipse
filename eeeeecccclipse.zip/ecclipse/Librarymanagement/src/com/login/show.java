package com.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class show
 */
@WebServlet("/show")
public class show extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String i=request.getParameter("id");
		try {
			PrintWriter out=response.getWriter();
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","Immanuvel*27");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from patient p,statusmsg s where p.id='"+i+"'and s.id='"+i+"'");
			if(rs.next()) {
				user u=new user();
				u.setId(rs.getInt("id"));
				u.setName(rs.getString("name"));
				u.setPhone(rs.getString("phone"));	
				u.setIn_time(rs.getString("intime"));
				u.setOut_time(rs.getString("outtime"));
				u.setDoc_time(rs.getString("doctortime"));
				u.setTot_time(rs.getString("total_time"));
				u.setW_time(rs.getString("waitingtime"));
				u.setStatus(rs.getString("message"));
				request.setAttribute("id", u.id);
				request.setAttribute("name", u.name);
				request.setAttribute("phone", u.phone);
				request.setAttribute("intime", u.in_time);
				request.setAttribute("outtime", u.out_time);
				request.setAttribute("doctime", u.doc_time);
				request.setAttribute("tottime", u.tot_time);
				request.setAttribute("waitingtime", u.w_time);
				request.setAttribute("status", u.status);
				
				RequestDispatcher rt=request.getRequestDispatcher("display.jsp");
				rt.forward(request, response);
				
			}else {
				out.println("<!DOCTYPE html>\r\n" + 
						"<html>\r\n" + 
						"<head>\r\n" + 
						"<link\r\n" + 
						"	href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css\"\r\n" + 
						"	rel=\"stylesheet\">\r\n" + 
						"<script\r\n" + 
						"	src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js\"></script>\r\n" + 
						"<meta charset=\"UTF-8\">\r\n" + 
						"<title>Insert title here</title>\r\n" + 
						"</head>\r\n" + 
						"<body>"
						+ "<div class=container text-center >");
				out.println("<h2 class='text-center text-danger mt-5'>Sorry user not exists</h2>"
						+ "<button class=\"btn btn-primary btn-lg\" onclick=\"window.location.href='dash.html'\">Return to Home</button>"
						+ "</div>"
						+ "</body></html>");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		
	}

}
