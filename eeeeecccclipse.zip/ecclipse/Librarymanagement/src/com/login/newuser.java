package com.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/newuser")
public class newuser extends HttpServlet{

	protected void doPost(HttpServletRequest request,HttpServletResponse response)
			throws IOException, ServletException {
		PrintWriter out=response.getWriter();
		String intime=request.getParameter("intime");
		String uname=request.getParameter("name");
		int doctime=Integer.parseInt(request.getParameter("dtime"));
		String ph=request.getParameter("phone");
		String outtime,sts;
		
		try {
			DateTimeFormatter df = DateTimeFormatter.ofPattern("HH:mm");
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","Immanuvel*27");
		Statement st=con.createStatement();
//		ResultSet rs=st.executeQuery("select * from user where id='"+i+"'");
//				if(rs.next()) {
//					user u=new user();
//					u.setId(rs.getInt("id"));
//					u.setemail(rs.getString("email"));
//					u.setPassword(rs.getString("password"));
//					request.setAttribute("id", u.id);
//					request.setAttribute("name", u.email);
//					RequestDispatcher rt=request.getRequestDispatcher("display.jsp");
//					rt.forward(request, response);
//					
//				}
		LocalTime lt = LocalTime.parse(intime);
		int timetaken=15+doctime;
		outtime=df.format(lt.plusMinutes(timetaken));
		if(timetaken-15>10) {
			sts="Sorry";
		}else if(timetaken-15==0) {
			sts="";
		}else {
			sts="";
		}
		int wt;
		if(doctime-10<0) {
			wt=0;
		}else {
			wt=doctime-10;
		}
		st.executeUpdate("insert into patient (name,intime,outtime,total_time,phone,waitingtime,doctortime) values('"+uname+"','"+intime+"','"+outtime+"','"+timetaken+"','"+ph+"','"+wt+"','"+doctime+"')");
		st.executeUpdate("insert into statusmsg(message,phone) values('"+sts+"','"+ph+"')");
		RequestDispatcher rt=request.getRequestDispatcher("dash.html");
		rt.forward(request, response);
		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}


