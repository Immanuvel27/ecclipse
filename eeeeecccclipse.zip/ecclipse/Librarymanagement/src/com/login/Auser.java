package com.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Auser
 */
@WebServlet("/Auser")
public class Auser extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id=request.getParameter("id");
		String intime=request.getParameter("intime");
		int doctime=Integer.parseInt(request.getParameter("dtime"));
		String outtime,sts;
		
		try {
			PrintWriter out=response.getWriter();
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Hospital","root","Immanuvel*27");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from patient where id='"+id+"'");
			if(rs.next()) {
				Statement st1=con.createStatement();
				Statement st2=con.createStatement();
				DateTimeFormatter df = DateTimeFormatter.ofPattern("HH:mm");
				LocalTime lt = LocalTime.parse(intime);
				int timetaken=15+doctime;
				outtime=df.format(lt.plusMinutes(timetaken));
				if(timetaken>25) {
					sts="Sorry";
				}else if(timetaken-15==0) {
					sts="";
				}else {
					sts="";
				}
				int wt;
				if(doctime-10<0) {
					wt=0;
				}else {
					wt=doctime-10;
				}
				st1.executeUpdate("update patient set intime='"+intime+"',outtime='"+outtime+"',total_time='"+timetaken+"'"
						+ ",waitingtime='"+wt+"',doctortime='"+doctime+"' where id='"+id+"' ");
				st2.executeUpdate("update statusmsg set message='"+sts+"'where id='"+rs.getString(1)+"'");
				out.println("<html>");
				out.println("<body>");
				out.println("<h2>successfully updated</h2>");
				out.println("<a href=Index.html><button>Home</button></a>");
				out.println("</body>");
				out.println("</html>");
//				RequestDispatcher rt=request.getRequestDispatcher("findAll.jsp");
//				rt.forward(request, response);
				}else {
					RequestDispatcher rt=request.getRequestDispatcher("view.html");
					rt.forward(request, response);
				}
		} catch (Exception e) {
			System.out.println("error"+e);
			e.printStackTrace();
		}
	}
	

}
