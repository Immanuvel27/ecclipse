package com.login;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

@WebServlet("/admin")
public class admin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json");
		PrintWriter out=response.getWriter();
		String email=request.getParameter("email");
		String password=request.getParameter("pass");
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","Immanuvel*27");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from admin where email='"+email+"' and pass='"+password+"' ");
			if(rs.next()) {
				 HttpSession session=request.getSession();  
			        session.setAttribute("email",email); 
			        
				Admin1 a=new Admin1();
				a.setId(rs.getInt("id"));
				a.setEmail(rs.getString("email"));
				a.setPass(rs.getString("pass"));
				request.setAttribute("Admin", a);
				
//				String resp=new Gson().toJson(a);
				out.println((a));
				
				
				response.sendRedirect("dash.html"); 
				
			}else {
				
				response.sendRedirect("Index.html"); 
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
