//document.getElementById("submit").addEventListener("click", LOGIN);

function LOGIN(e){
//	e.preventDefault();
//	e.preventDefault();
	 var email = document.getElementById("email").value;
	  var pass = document.getElementById("pass").value;
	  //alert("email:"+email+"  pass:"+pass);
	  var obj={Email:email,Password:pass}
	  alert(JSON.stringify(obj));
//	  console.log(JSON.stringify(obj));
	  form.submit();
//	  console.log(obj);
	  
}