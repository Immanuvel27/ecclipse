/**
 * 
 */
function logout(){
//	 window.localStorage.clear();
	    window.location =   "/logout";
}