package railwayTicket;

public class Train {

}
