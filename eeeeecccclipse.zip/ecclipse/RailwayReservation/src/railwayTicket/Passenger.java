package railwayTicket;

import java.util.Scanner;

public class Passenger {
	String name;
	int age;
	String sex;

	void getPassenger() {
		Scanner in = new Scanner(System.in);

	}

}
